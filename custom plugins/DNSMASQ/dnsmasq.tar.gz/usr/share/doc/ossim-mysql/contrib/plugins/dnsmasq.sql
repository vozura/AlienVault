-- DNSMASQ
-- Plugin id:9113

DELETE FROM plugin WHERE id = "9113";
DELETE FROM plugin_sid where plugin_id = "9113";

INSERT IGNORE INTO plugin (id, type, name, description) VALUES (9113, 1, 'dnsmasq', 'DNSMASQ');
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (9113, 1, NULL, NULL, NULL, 'DNS Cached', 1, 3);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (9113, 2, NULL, NULL, NULL, 'DNS Query', 1, 3);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (9113, 3, NULL, NULL, NULL, 'DNS Reply', 1, 3);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (9113, 4, NULL, NULL, NULL, 'DNS Forwarded', 1, 3);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (9113, 5, NULL, NULL, NULL, 'DNS Config', 1, 3);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (9113, 6, NULL, NULL, NULL, 'DHCP ', 1, 3);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (9113, 7, NULL, NULL, NULL, 'DHCP Discover', 1, 3);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (9113, 8, NULL, NULL, NULL, 'DHCP Acknowledge', 1, 3);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (9113, 9, NULL, NULL, NULL, 'DHCP Not acknowledged', 1, 3);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (9113, 10, NULL, NULL, NULL, 'DHCP Request', 1, 3);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (9113, 11, NULL, NULL, NULL, 'DHCP Offer', 1, 3);
INSERT IGNORE INTO plugin_sid (plugin_id, sid, category_id, subcategory_id, class_id, name, priority, reliability) VALUES (9113, 12, NULL, NULL, NULL, 'DHCP Inform', 1, 3);
